export interface User {
  id: string
  email: string
  full_name: string
  role: 'customer' | 'seller' | 'admin'
  avatar_url?: string
  phone?: string
  address?: string
  created_at: string
  updated_at: string
}

export interface Product {
  id: string
  name: string
  description: string
  price: number
  category: string
  subcategory?: string
  image_url: string
  images?: string[]
  stock_quantity: number
  seller_id: string
  seller?: User
  rating: number
  reviews_count: number
  tags?: string[]
  specifications?: Record<string, any>
  created_at: string
  updated_at: string
}

export interface CartItem {
  id: string
  user_id: string
  product_id: string
  product: Product
  quantity: number
  created_at: string
}

export interface Order {
  id: string
  user_id: string
  user?: User
  total_amount: number
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled'
  shipping_address: Address
  payment_method: string
  payment_status: 'pending' | 'completed' | 'failed'
  order_items: OrderItem[]
  created_at: string
  updated_at: string
}

export interface OrderItem {
  id: string
  order_id: string
  product_id: string
  product: Product
  quantity: number
  price: number
  created_at: string
}

export interface Address {
  street: string
  city: string
  state: string
  postal_code: string
  country: string
}

export interface Review {
  id: string
  product_id: string
  user_id: string
  user?: User
  rating: number
  comment: string
  created_at: string
}

export interface Category {
  id: string
  name: string
  description?: string
  image_url?: string
  parent_id?: string
  subcategories?: Category[]
}

export interface AuthContextType {
  user: User | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, fullName: string) => Promise<void>
  signOut: () => Promise<void>
  updateProfile: (data: Partial<User>) => Promise<void>
}

export interface CartContextType {
  items: CartItem[]
  loading: boolean
  addToCart: (productId: string, quantity?: number) => Promise<void>
  updateQuantity: (itemId: string, quantity: number) => Promise<void>
  removeFromCart: (itemId: string) => Promise<void>
  clearCart: () => Promise<void>
  getTotalPrice: () => number
  getTotalItems: () => number
}